package app.naturalfemalevoice.convert

import app.naturalfemalevoice.audio.Dsp
import app.naturalfemalevoice.audio.PcmAudio
import app.naturalfemalevoice.audio.PitchShifter
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers

/**
 * Motor BÁSICO (sem IA, sem rede, qualquer dispositivo): mudança de tom/formantes.
 * Trabalha a ≤ 24 kHz para manter o custo baixo em telemóveis modestos.
 */
class LocalDspConverter : VoiceConverter {
    override suspend fun convert(input: PcmAudio, params: ConversionParams, onProgress: (Float) -> Unit): PcmAudio =
        withContext(Dispatchers.Default) {
            val ctx = currentCoroutineContext()
            val workRate = minOf(input.sampleRate, 24_000)
            var x = Dsp.resample(input.samples, input.sampleRate, workRate)
            x = Dsp.highPass(x, workRate, 60.0)
            onProgress(0.05f)
            x = PitchShifter.pitchShift(
                x, workRate, params.pitchRatio.coerceIn(0.5, 2.0),
                onProgress = { onProgress(0.05f + 0.9f * it) },
                check = { ctx.ensureActive() },
            )
            x = Dsp.normalizePeak(x)
            onProgress(1f)
            PcmAudio(x, workRate)
        }
}
