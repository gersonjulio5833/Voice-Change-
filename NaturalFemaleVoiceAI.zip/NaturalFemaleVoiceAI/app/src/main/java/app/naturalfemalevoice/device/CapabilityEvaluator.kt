package app.naturalfemalevoice.device

enum class Tier { LOW, MID, HIGH }

class DeviceReport(
    val sdk: Int,
    val abis: List<String>,
    val totalRamMb: Long,
    val cores: Int,
    val freeStorageMb: Long,
    val lowRamFlag: Boolean,
    val lowLatencyAudio: Boolean,
    val hasMic: Boolean,
    val tier: Tier,
    val localAiSupported: Boolean,
    /** Informativo: o dispositivo poderia, em teoria, suportar processamento em tempo real. NÃO implementado. */
    val realtimeCandidate: Boolean,
    val notes: List<String>,
)

/** Lógica pura (testável na JVM). Limiares documentados em docs/COMPATIBILIDADE.md. */
object CapabilityEvaluator {
    const val MIN_RAM_LOCAL_AI_MB = 2800L // "4 GB" de marketing ≈ 3.5 GB reportados
    const val MIN_STORAGE_LOCAL_AI_MB = 300L

    fun evaluate(
        sdk: Int,
        abis: List<String>,
        totalRamMb: Long,
        cores: Int,
        freeStorageMb: Long,
        lowRamFlag: Boolean,
        lowLatencyAudio: Boolean,
        hasMic: Boolean,
    ): DeviceReport {
        val is64 = abis.any { it == "arm64-v8a" || it == "x86_64" }
        val tier = when {
            lowRamFlag || totalRamMb < MIN_RAM_LOCAL_AI_MB -> Tier.LOW
            totalRamMb >= 5500 && cores >= 8 -> Tier.HIGH
            else -> Tier.MID
        }
        val notes = ArrayList<String>()
        if (!hasMic) notes += "Sem microfone detetado: pode importar ficheiros de áudio em vez de gravar."
        if (!is64) notes += "CPU de 32 bits: IA local desativada (modelos ONNX exigem muita memória). Use o motor básico ou a nuvem."
        if (lowRamFlag || totalRamMb < MIN_RAM_LOCAL_AI_MB) notes += "RAM limitada (${totalRamMb} MB): IA local desativada. Motor básico e nuvem disponíveis."
        if (freeStorageMb < MIN_STORAGE_LOCAL_AI_MB) notes += "Pouco armazenamento livre (${freeStorageMb} MB): libertar espaço antes de importar modelos."

        val localAi = is64 && tier != Tier.LOW && freeStorageMb >= MIN_STORAGE_LOCAL_AI_MB
        val rt = lowLatencyAudio && cores >= 6 && tier != Tier.LOW
        return DeviceReport(sdk, abis, totalRamMb, cores, freeStorageMb, lowRamFlag, lowLatencyAudio, hasMic, tier, localAi, rt, notes)
    }
}
