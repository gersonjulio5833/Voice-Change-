package app.naturalfemalevoice.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder

/** Descodifica qualquer áudio suportado pelo Android (MP3, M4A, WAV, OGG…) para PCM mono float. */
object AudioDecoder {

    fun decode(context: Context, uri: Uri, maxSeconds: Int = 300): PcmAudio =
        decodeWith(maxSeconds) { it.setDataSource(context, uri, null) }

    fun decodeAsset(context: Context, assetPath: String, maxSeconds: Int = 300): PcmAudio {
        val afd = context.assets.openFd(assetPath)
        try {
            return decodeWith(maxSeconds) { it.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length) }
        } finally {
            afd.close()
        }
    }

    private class FloatBuf {
        var data = FloatArray(1 shl 16)
        var size = 0
        fun add(v: Float) {
            if (size == data.size) data = data.copyOf(data.size * 2)
            data[size++] = v
        }
    }

    private fun decodeWith(maxSeconds: Int, setup: (MediaExtractor) -> Unit): PcmAudio {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            setup(extractor)
            var track = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                    track = i; format = f; break
                }
            }
            require(track >= 0 && format != null) { "O ficheiro não contém faixa de áudio." }
            extractor.selectTrack(track)

            val mime = format.getString(MediaFormat.KEY_MIME)!!
            val c = MediaCodec.createDecoderByType(mime)
            codec = c
            c.configure(format, null, null, 0)
            c.start()

            var sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val out = FloatBuf()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false

            while (!outputDone) {
                if (!inputDone) {
                    val ii = c.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val buf = c.getInputBuffer(ii)!!
                        val n = extractor.readSampleData(buf, 0)
                        if (n < 0) {
                            c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            c.queueInputBuffer(ii, 0, n, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val oi = c.dequeueOutputBuffer(info, 10_000)
                if (oi >= 0) {
                    val buf = c.getOutputBuffer(oi)!!
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    val sb = buf.order(ByteOrder.nativeOrder()).asShortBuffer()
                    val ch = max1(channels)
                    val frames = sb.remaining() / ch
                    for (f in 0 until frames) {
                        var acc = 0f
                        for (k in 0 until ch) acc += sb.get() / 32768f
                        out.add(acc / ch)
                    }
                    c.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                    if (out.size > maxSeconds.toLong() * sampleRate) outputDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = c.outputFormat
                    sampleRate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
            require(out.size > 0) { "Não foi possível descodificar o áudio." }
            return PcmAudio(out.data.copyOf(out.size), sampleRate)
        } finally {
            try { codec?.stop() } catch (_: Throwable) {}
            try { codec?.release() } catch (_: Throwable) {}
            extractor.release()
        }
    }

    private fun max1(v: Int) = if (v < 1) 1 else v
}
