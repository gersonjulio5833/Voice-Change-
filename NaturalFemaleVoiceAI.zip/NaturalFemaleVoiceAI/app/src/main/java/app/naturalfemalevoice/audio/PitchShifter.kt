package app.naturalfemalevoice.audio

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Mudança de tom/timbre por WSOLA (time-stretch) + reamostragem.
 * Move o tom E os formantes na mesma proporção ("tamanho do trato vocal").
 * NÃO é clonagem de voz por IA — é o motor básico, funciona em qualquer telemóvel.
 */
object PitchShifter {

    fun timeStretch(
        x: FloatArray,
        sampleRate: Int,
        stretch: Double,
        onProgress: (Float) -> Unit = {},
        check: () -> Unit = {},
    ): FloatArray {
        require(stretch > 0.25 && stretch < 4.0) { "Fator de stretch fora do intervalo." }
        val frame = (sampleRate * 0.032).toInt() / 2 * 2
        if (x.size < frame * 4 || abs(stretch - 1.0) < 1e-4) return x.copyOf()

        val hopS = frame / 2
        val tol = (sampleRate * 0.008).toInt()
        val hopA = hopS / stretch
        val outLen = (x.size * stretch).toInt()
        val out = FloatArray(outLen + frame)
        val norm = FloatArray(outLen + frame)
        val win = FloatArray(frame) { (0.5 - 0.5 * cos(2 * PI * it / frame)).toFloat() }

        for (j in 0 until frame) { out[j] += x[j] * win[j]; norm[j] += win[j] }
        var prev = 0
        var k = 1
        var lastEnd = frame
        while (true) {
            val outPos = k * hopS
            if (outPos >= outLen) break
            val nominal = (k * hopA).toInt()
            val lo = max(0, nominal - tol)
            val hi = min(x.size - frame, nominal + tol)
            if (lo > hi) break
            val tStart = prev + hopS
            var best = min(max(nominal, lo), hi)
            if (tStart + hopS <= x.size) {
                var bestScore = -Double.MAX_VALUE
                var c = lo
                while (c <= hi) {
                    var dot = 0.0
                    var e = 0.0
                    var j = 0
                    while (j < hopS) {
                        val a = x[c + j]
                        dot += a * x[tStart + j]
                        e += a * a
                        j += 2
                    }
                    val score = dot / sqrt(e + 1e-9)
                    if (score > bestScore) { bestScore = score; best = c }
                    c += 2
                }
            }
            for (j in 0 until frame) {
                out[outPos + j] += x[best + j] * win[j]
                norm[outPos + j] += win[j]
            }
            lastEnd = outPos + frame
            prev = best
            k++
            if (k % 64 == 0) {
                check()
                onProgress(min(1f, outPos.toFloat() / outLen))
            }
        }
        val finalLen = min(outLen, lastEnd)
        return FloatArray(finalLen) { val n = norm[it]; if (n > 1e-3f) out[it] / n else out[it] }
    }

    /** [ratio] > 1 sobe tom+formantes (voz mais aguda); < 1 desce. Mantém a duração. */
    fun pitchShift(
        x: FloatArray,
        sampleRate: Int,
        ratio: Double,
        onProgress: (Float) -> Unit = {},
        check: () -> Unit = {},
    ): FloatArray {
        val stretched = timeStretch(x, sampleRate, ratio, onProgress, check)
        val src = if (ratio > 1.0) Dsp.lowPass(stretched, 0.46 / ratio) else stretched
        return Dsp.resampleStep(src, ratio)
    }
}
