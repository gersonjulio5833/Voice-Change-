package app.naturalfemalevoice.convert

import app.naturalfemalevoice.audio.Dsp
import app.naturalfemalevoice.audio.PcmAudio
import app.naturalfemalevoice.audio.WavIO
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Motor de nuvem GENÉRICO: POST multipart/form-data para um endpoint HTTPS configurado pelo utilizador.
 * Campos: "audio" (WAV 16 kHz mono), "reference" (WAV opcional), "pitch_ratio" (texto).
 * Resposta esperada: corpo WAV (PCM16 ou float32). Ver docs/MODELOS.md.
 * O URL e o token são introduzidos pelo utilizador em runtime; nada está no código.
 */
class CloudVoiceConverter(
    private val endpoint: String,
    private val token: String?,
) : VoiceConverter {

    override suspend fun convert(input: PcmAudio, params: ConversionParams, onProgress: (Float) -> Unit): PcmAudio =
        withContext(Dispatchers.IO) {
            val url = URL(endpoint)
            require(url.protocol == "https") { "O endpoint de nuvem tem de usar HTTPS." }
            val upRate = 16_000
            val audioWav = WavIO.toBytes(PcmAudio(Dsp.resample(input.samples, input.sampleRate, upRate), upRate))
            val refWav = params.reference?.let {
                val r = minOf(it.sampleRate, 16_000)
                WavIO.toBytes(PcmAudio(Dsp.resample(it.samples, it.sampleRate, r), r))
            }
            onProgress(0.1f)

            val boundary = "----nfv${System.currentTimeMillis()}"
            val conn = url.openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.connectTimeout = 15_000
                conn.readTimeout = 180_000
                conn.setChunkedStreamingMode(64 * 1024)
                conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                if (!token.isNullOrBlank()) conn.setRequestProperty("Authorization", "Bearer $token")

                DataOutputStream(conn.outputStream.buffered()).use { out ->
                    fun text(name: String, value: String) {
                        out.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n")
                    }
                    fun file(name: String, bytes: ByteArray) {
                        out.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"; filename=\"$name.wav\"\r\nContent-Type: audio/wav\r\n\r\n")
                        out.write(bytes)
                        out.writeBytes("\r\n")
                    }
                    text("pitch_ratio", params.pitchRatio.toString())
                    file("audio", audioWav)
                    if (refWav != null) file("reference", refWav)
                    out.writeBytes("--$boundary--\r\n")
                }
                onProgress(0.5f)

                val code = conn.responseCode
                if (code !in 200..299) {
                    val msg = conn.errorStream?.use { String(it.readBytes().take(300).toByteArray()) }.orEmpty()
                    error("Servidor devolveu HTTP $code. $msg")
                }
                val bytes = conn.inputStream.use { it.readBytes() }
                onProgress(0.95f)
                val result = WavIO.read(bytes)
                onProgress(1f)
                result
            } finally {
                conn.disconnect()
            }
        }
}
