package app.naturalfemalevoice.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * URL em SharedPreferences normais; token em EncryptedSharedPreferences (Keystore).
 * Se o Keystore falhar (comum em alguns ROMs), o token fica só em memória nesta sessão.
 */
class SettingsStore(context: Context) {
    private val plain: SharedPreferences = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val secure: SharedPreferences? = try {
        val mk = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context, "secure_settings", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    } catch (_: Throwable) { null }
    private var memoryToken: String = ""

    var cloudUrl: String
        get() = plain.getString("cloud_url", "") ?: ""
        set(v) { plain.edit().putString("cloud_url", v).apply() }

    var cloudToken: String
        get() = secure?.getString("cloud_token", "") ?: memoryToken
        set(v) {
            memoryToken = v
            secure?.edit()?.putString("cloud_token", v)?.apply()
        }
}
