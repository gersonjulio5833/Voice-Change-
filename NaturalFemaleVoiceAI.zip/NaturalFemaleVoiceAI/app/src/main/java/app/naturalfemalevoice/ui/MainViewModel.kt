package app.naturalfemalevoice.ui

import android.app.Application
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.naturalfemalevoice.audio.AudioDecoder
import app.naturalfemalevoice.audio.AudioRecorder
import app.naturalfemalevoice.audio.PcmAudio
import app.naturalfemalevoice.audio.PcmPlayer
import app.naturalfemalevoice.audio.WavIO
import app.naturalfemalevoice.convert.CloudVoiceConverter
import app.naturalfemalevoice.convert.ConversionParams
import app.naturalfemalevoice.convert.LocalDspConverter
import app.naturalfemalevoice.convert.OnnxVoiceConverter
import app.naturalfemalevoice.convert.VoiceConverter
import app.naturalfemalevoice.data.References
import app.naturalfemalevoice.data.SettingsStore
import app.naturalfemalevoice.device.DeviceCapabilities
import app.naturalfemalevoice.device.DeviceReport
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

enum class Engine { DSP, ONNX, CLOUD }
enum class PlayTarget { INPUT, OUTPUT, REFERENCE }

data class UiState(
    val device: DeviceReport? = null,
    val engine: Engine = Engine.DSP,
    val pitchRatio: Float = 1.25f,
    val referenceId: String? = null,
    val isRecording: Boolean = false,
    val level: Float = 0f,
    val hasInput: Boolean = false,
    val hasOutput: Boolean = false,
    val inputInfo: String? = null,
    val outputInfo: String? = null,
    val busy: Boolean = false,
    val progress: Float = 0f,
    val playing: PlayTarget? = null,
    val message: String? = null,
    val modelImported: Boolean = false,
    val cloudUrl: String = "",
    val cloudToken: String = "",
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val settings = SettingsStore(ctx)
    private val recorder = AudioRecorder()
    private val player = PcmPlayer()
    private val modelFile = File(ctx.filesDir, "models/model.onnx")

    private var input: PcmAudio? = null
    private var output: PcmAudio? = null
    private var work: Job? = null

    private val _state = MutableStateFlow(
        UiState(
            modelImported = modelFile.exists(),
            cloudUrl = settings.cloudUrl,
            cloudToken = settings.cloudToken,
        ),
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.Default) {
            val report = try { DeviceCapabilities.collect(ctx) } catch (_: Throwable) { null }
            _state.update { it.copy(device = report) }
        }
    }

    private fun describe(a: PcmAudio) = String.format(Locale.getDefault(), "%.1f s · %d Hz", a.durationSec, a.sampleRate)
    fun consumeMessage() = _state.update { it.copy(message = null) }
    private fun msg(t: String) = _state.update { it.copy(message = t) }

    // ---------- Entrada ----------
    fun startRecording() {
        if (_state.value.isRecording || _state.value.busy) return
        stopPlayback()
        work = viewModelScope.launch {
            _state.update { it.copy(isRecording = true, message = null) }
            try {
                val a = recorder.record(300) { lvl -> _state.update { s -> s.copy(level = lvl) } }
                setInput(a)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                msg(e.message ?: "Falha na gravação.")
            } finally {
                _state.update { it.copy(isRecording = false, level = 0f) }
            }
        }
    }

    fun stopRecording() = recorder.stop()

    fun importAudio(uri: Uri) {
        if (_state.value.busy) return
        viewModelScope.launch {
            try {
                val a = withContext(Dispatchers.IO) { AudioDecoder.decode(ctx, uri, 300) }
                setInput(a)
            } catch (e: Throwable) {
                msg("Não foi possível abrir o áudio: ${e.message}")
            }
        }
    }

    private fun setInput(a: PcmAudio) {
        input = a
        output = null
        _state.update { it.copy(hasInput = true, hasOutput = false, inputInfo = describe(a), outputInfo = null) }
    }

    // ---------- Configuração ----------
    fun setEngine(e: Engine) = _state.update { it.copy(engine = e) }
    fun setPitch(v: Float) = _state.update { it.copy(pitchRatio = v) }
    fun setReference(id: String?) = _state.update { it.copy(referenceId = id) }
    fun setCloudUrl(v: String) { settings.cloudUrl = v; _state.update { it.copy(cloudUrl = v) } }
    fun setCloudToken(v: String) { settings.cloudToken = v; _state.update { it.copy(cloudToken = v) } }

    fun importModel(uri: Uri) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    modelFile.parentFile?.mkdirs()
                    val tmp = File(modelFile.parentFile, "model.tmp")
                    ctx.contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    if (modelFile.exists()) modelFile.delete()
                    check(tmp.renameTo(modelFile)) { "Não foi possível guardar o modelo." }
                }
                _state.update { it.copy(modelImported = true) }
                msg("Modelo importado.")
            } catch (e: Throwable) {
                msg("Falha ao importar o modelo: ${e.message}")
            }
        }
    }

    // ---------- Conversão ----------
    private suspend fun buildConverter(s: UiState): Pair<VoiceConverter, ConversionParams> {
        val ref: PcmAudio? = s.referenceId?.let { id -> withContext(Dispatchers.IO) { References.load(ctx, id) } }
        val params = ConversionParams(s.pitchRatio.toDouble(), ref)
        val conv: VoiceConverter = when (s.engine) {
            Engine.DSP -> LocalDspConverter()
            Engine.ONNX -> {
                val d = s.device
                check(d == null || d.localAiSupported) {
                    "Este dispositivo não cumpre os requisitos de IA local (RAM/CPU 64 bits/armazenamento). Use o motor básico ou a nuvem."
                }
                check(modelFile.exists()) { "Importe primeiro um modelo .onnx." }
                OnnxVoiceConverter(modelFile)
            }
            Engine.CLOUD -> {
                check(s.cloudUrl.startsWith("https://")) { "Indique um endpoint HTTPS válido." }
                CloudVoiceConverter(s.cloudUrl.trim(), s.cloudToken.ifBlank { null })
            }
        }
        return conv to params
    }

    fun convert() {
        val src = input ?: return
        if (_state.value.busy || _state.value.isRecording) return
        stopPlayback()
        work = viewModelScope.launch {
            _state.update { it.copy(busy = true, progress = 0f, message = null) }
            try {
                val (conv, params) = buildConverter(_state.value)
                val res = conv.convert(src, params) { p -> _state.update { s -> s.copy(progress = p) } }
                output = res
                _state.update { it.copy(hasOutput = true, outputInfo = describe(res)) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: OutOfMemoryError) {
                msg("Memória insuficiente. Use um áudio mais curto ou o motor básico.")
            } catch (e: Throwable) {
                msg(e.message ?: "Falha na conversão.")
            } finally {
                _state.update { it.copy(busy = false) }
            }
        }
    }

    fun cancelWork() { work?.cancel(); recorder.stop() }

    // ---------- Reprodução ----------
    fun play(target: PlayTarget) {
        viewModelScope.launch {
            try {
                val a: PcmAudio = when (target) {
                    PlayTarget.INPUT -> input
                    PlayTarget.OUTPUT -> output
                    PlayTarget.REFERENCE -> _state.value.referenceId?.let {
                        withContext(Dispatchers.IO) { References.load(ctx, it) }
                    }
                } ?: return@launch
                _state.update { it.copy(playing = target) }
                player.play(viewModelScope, a) { err ->
                    _state.update { it.copy(playing = null, message = err?.message ?: it.message) }
                }
            } catch (e: Throwable) {
                msg("Erro ao reproduzir: ${e.message}")
            }
        }
    }

    fun stopPlayback() {
        player.stop()
        _state.update { it.copy(playing = null) }
    }

    // ---------- Exportação ----------
    fun saveOutput(uri: Uri) {
        val a = output ?: return
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    ctx.contentResolver.openOutputStream(uri)!!.use { WavIO.write(it, a) }
                }
                msg("Áudio guardado.")
            } catch (e: Throwable) {
                msg("Falha ao guardar: ${e.message}")
            }
        }
    }

    fun prepareShare(onReady: (Uri) -> Unit) {
        val a = output ?: return
        viewModelScope.launch {
            try {
                val uri = withContext(Dispatchers.IO) {
                    val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
                    val f = File(dir, "voz_convertida.wav")
                    f.outputStream().use { WavIO.write(it, a) }
                    FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
                }
                onReady(uri)
            } catch (e: Throwable) {
                msg("Falha ao partilhar: ${e.message}")
            }
        }
    }

    override fun onCleared() {
        player.stop()
        recorder.stop()
    }
}
