package app.naturalfemalevoice.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext
import kotlin.math.abs
import kotlin.math.max

/** Grava microfone em PCM16 mono a 44.1 kHz (taxa garantida pelo Android). */
class AudioRecorder {
    @Volatile private var recording = false

    fun stop() { recording = false }

    @SuppressLint("MissingPermission") // permissão verificada na UI antes de chamar
    suspend fun record(maxSeconds: Int = 300, onLevel: (Float) -> Unit = {}): PcmAudio =
        withContext(Dispatchers.IO) {
            val rate = 44_100
            val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            check(minBuf > 0) { "Este dispositivo não suporta gravação a 44.1 kHz." }
            val rec = AudioRecord(
                MediaRecorder.AudioSource.MIC, rate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf * 4,
            )
            check(rec.state == AudioRecord.STATE_INITIALIZED) { "Não foi possível abrir o microfone (em uso por outra app?)." }

            val total = maxSeconds * rate
            val data = FloatArray(total)
            var n = 0
            val buf = ShortArray(minBuf / 2)
            recording = true
            try {
                rec.startRecording()
                while (recording && coroutineContext.isActive && n < total) {
                    val r = rec.read(buf, 0, minOf(buf.size, total - n))
                    if (r < 0) error("Erro de leitura do microfone ($r).")
                    var peak = 0f
                    for (i in 0 until r) {
                        val v = buf[i] / 32768f
                        data[n + i] = v
                        peak = max(peak, abs(v))
                    }
                    n += r
                    onLevel(peak)
                }
            } finally {
                recording = false
                try { rec.stop() } catch (_: Throwable) {}
                rec.release()
            }
            require(n > rate / 4) { "Gravação demasiado curta." }
            PcmAudio(data.copyOf(n), rate)
        }
}
