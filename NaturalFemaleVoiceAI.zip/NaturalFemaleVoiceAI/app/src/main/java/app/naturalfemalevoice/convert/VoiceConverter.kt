package app.naturalfemalevoice.convert

import app.naturalfemalevoice.audio.PcmAudio

class ConversionParams(
    /** Razão tom+formantes do motor básico (1.0 = sem alteração). */
    val pitchRatio: Double,
    /** Voz de referência (opcional) para motores de IA que a aceitem. */
    val reference: PcmAudio?,
)

interface VoiceConverter {
    /** Corre em Dispatchers.Default/IO; deve verificar cancelamento de coroutine. */
    suspend fun convert(input: PcmAudio, params: ConversionParams, onProgress: (Float) -> Unit): PcmAudio
}
