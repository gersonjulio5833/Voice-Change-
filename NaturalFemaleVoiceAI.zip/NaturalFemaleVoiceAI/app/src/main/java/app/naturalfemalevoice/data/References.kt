package app.naturalfemalevoice.data

import android.content.Context
import app.naturalfemalevoice.audio.AudioDecoder
import app.naturalfemalevoice.audio.PcmAudio

class ReferenceVoice(val id: String, val label: String, val asset: String)

/** Áudios de referência incluídos no APK (assets/reference_voices). */
object References {
    val all = listOf(
        ReferenceVoice("sussurro_pt", "Sussurro suave (PT, ~2 s)", "reference_voices/ref_sussurro_pt.mp3"),
        ReferenceVoice("sombria_en", "Voz sombria (EN, ~2 s)", "reference_voices/ref_sombria_en.mp3"),
        ReferenceVoice("voicemail_en", "Voicemail alegre (EN, ~2 min)", "reference_voices/ref_voicemail_en.mp3"),
    )

    fun load(context: Context, id: String): PcmAudio {
        val ref = all.first { it.id == id }
        return AudioDecoder.decodeAsset(context, ref.asset, maxSeconds = 120)
    }
}
