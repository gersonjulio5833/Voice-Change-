package app.naturalfemalevoice.device

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.StatFs

object DeviceCapabilities {
    fun collect(context: Context): DeviceReport {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val pm = context.packageManager
        val free = try {
            val st = StatFs(context.filesDir.absolutePath)
            st.availableBytes / (1024 * 1024)
        } catch (_: Throwable) { 0L }
        return CapabilityEvaluator.evaluate(
            sdk = Build.VERSION.SDK_INT,
            abis = Build.SUPPORTED_ABIS.toList(),
            totalRamMb = mi.totalMem / (1024 * 1024),
            cores = Runtime.getRuntime().availableProcessors(),
            freeStorageMb = free,
            lowRamFlag = am.isLowRamDevice,
            lowLatencyAudio = pm.hasSystemFeature(PackageManager.FEATURE_AUDIO_LOW_LATENCY),
            hasMic = pm.hasSystemFeature(PackageManager.FEATURE_MICROPHONE),
        )
    }
}
