package app.naturalfemalevoice.ui

import android.Manifest
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import app.naturalfemalevoice.data.References
import kotlin.math.ln

@Composable
fun MainScreen(vm: MainViewModel) {
    val s by vm.state.collectAsState()
    val ctx = LocalContext.current

    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.startRecording()
    }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::importAudio) }
    val pickModel = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::importModel) }
    val saveWav = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/x-wav")) { it?.let(vm::saveOutput) }

    fun record() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            vm.startRecording()
        } else micPerm.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun share() = vm.prepareShare { uri ->
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "audio/wav"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Partilhar áudio"))
    }

    Surface(Modifier.safeDrawingPadding(), color = MaterialTheme.colorScheme.background) {
        BoxWithConstraints {
            val wide = maxWidth >= 720.dp
            val device: @Composable () -> Unit = { DeviceCard(s) }
            val source: @Composable () -> Unit = {
                SourceCard(s, onRecord = ::record, onStop = vm::stopRecording,
                    onImport = { pickAudio.launch(arrayOf("audio/*")) }, vm = vm)
            }
            val engine: @Composable () -> Unit = {
                EngineCard(s, vm, onPickModel = { pickModel.launch(arrayOf("*/*")) })
            }
            val result: @Composable () -> Unit = {
                ResultCard(s, vm, onSave = { saveWav.launch("voz_convertida.wav") }, onShare = ::share)
            }
            Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
                Text("Natural Female Voice AI", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(12.dp))
                if (wide) {
                    Row {
                        Column(Modifier.weight(1f).padding(end = 8.dp)) { device(); Gap(); source() }
                        Column(Modifier.weight(1f).padding(start = 8.dp)) { engine(); Gap(); result() }
                    }
                } else {
                    device(); Gap(); source(); Gap(); engine(); Gap(); result()
                }
                s.message?.let {
                    Gap()
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(it, color = MaterialTheme.colorScheme.error)
                            OutlinedButton(onClick = vm::consumeMessage) { Text("OK") }
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun Gap() = Spacer(Modifier.height(12.dp))

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun DeviceCard(s: UiState) = Section("Dispositivo") {
    val d = s.device
    if (d == null) Text("A analisar…") else {
        Text("Android API ${d.sdk} · ${d.abis.firstOrNull() ?: "?"} · ${d.cores} núcleos")
        Text("RAM ${d.totalRamMb} MB · livre ${d.freeStorageMb} MB · nível ${d.tier}")
        Text("IA local: ${if (d.localAiSupported) "suportada" else "não suportada"}")
        Text("Tempo real: não implementado nesta versão")
        d.notes.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
private fun SourceCard(s: UiState, onRecord: () -> Unit, onStop: () -> Unit, onImport: () -> Unit, vm: MainViewModel) =
    Section("1. Áudio de entrada") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (s.isRecording) Button(onClick = onStop) { Text("Parar") }
            else Button(onClick = onRecord, enabled = !s.busy) { Text("Gravar") }
            Spacer(Modifier.padding(4.dp))
            OutlinedButton(onClick = onImport, enabled = !s.busy && !s.isRecording) { Text("Importar") }
        }
        if (s.isRecording) {
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { s.level.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
        }
        s.inputInfo?.let {
            Spacer(Modifier.height(8.dp))
            Text("Carregado: $it")
            if (s.playing == PlayTarget.INPUT) OutlinedButton(onClick = vm::stopPlayback) { Text("Parar") }
            else OutlinedButton(onClick = { vm.play(PlayTarget.INPUT) }) { Text("Ouvir original") }
        }
    }

@Composable
private fun EngineCard(s: UiState, vm: MainViewModel, onPickModel: () -> Unit) = Section("2. Motor de conversão") {
    EngineRow(s.engine == Engine.DSP, "Básico (DSP, offline, todos os telemóveis)") { vm.setEngine(Engine.DSP) }
    EngineRow(s.engine == Engine.ONNX, "IA local (ONNX, requer modelo)") { vm.setEngine(Engine.ONNX) }
    EngineRow(s.engine == Engine.CLOUD, "IA na nuvem (HTTPS, requer endpoint)") { vm.setEngine(Engine.CLOUD) }
    Spacer(Modifier.height(8.dp))

    when (s.engine) {
        Engine.DSP -> {
            val semis = 12f * (ln(s.pitchRatio.toDouble()) / ln(2.0)).toFloat()
            Text("Tom/timbre: +${"%.1f".format(semis)} semitons (×${"%.2f".format(s.pitchRatio)})")
            Slider(value = s.pitchRatio, onValueChange = vm::setPitch, valueRange = 1.0f..1.6f)
            Text("O motor básico sobe tom e formantes em conjunto; não clona a voz.", style = MaterialTheme.typography.bodySmall)
        }
        Engine.ONNX -> {
            Text(if (s.modelImported) "Modelo importado." else "Nenhum modelo importado.")
            OutlinedButton(onClick = onPickModel) { Text("Importar modelo .onnx") }
        }
        Engine.CLOUD -> {
            OutlinedTextField(value = s.cloudUrl, onValueChange = vm::setCloudUrl, label = { Text("URL HTTPS") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = s.cloudToken, onValueChange = vm::setCloudToken, label = { Text("Token (opcional)") },
                singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        }
    }

    Spacer(Modifier.height(12.dp))
    Text("Voz de referência (usada por IA local/nuvem)", style = MaterialTheme.typography.labelLarge)
    EngineRow(s.referenceId == null, "Nenhuma") { vm.setReference(null) }
    References.all.forEach { r -> EngineRow(s.referenceId == r.id, r.label) { vm.setReference(r.id) } }
    if (s.referenceId != null) {
        if (s.playing == PlayTarget.REFERENCE) OutlinedButton(onClick = vm::stopPlayback) { Text("Parar") }
        else OutlinedButton(onClick = { vm.play(PlayTarget.REFERENCE) }) { Text("Ouvir referência") }
    }
}

@Composable
private fun EngineRow(selected: Boolean, label: String, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun ResultCard(s: UiState, vm: MainViewModel, onSave: () -> Unit, onShare: () -> Unit) = Section("3. Converter e exportar") {
    if (s.busy) {
        LinearProgressIndicator(progress = { s.progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = vm::cancelWork) { Text("Cancelar") }
    } else {
        Button(onClick = vm::convert, enabled = s.hasInput && !s.isRecording, modifier = Modifier.fillMaxWidth()) { Text("Converter") }
    }
    if (s.hasOutput) {
        Spacer(Modifier.height(8.dp))
        Text("Resultado: ${s.outputInfo}")
        Row {
            if (s.playing == PlayTarget.OUTPUT) OutlinedButton(onClick = vm::stopPlayback) { Text("Parar") }
            else Button(onClick = { vm.play(PlayTarget.OUTPUT) }) { Text("Pré-visualizar") }
        }
        Row {
            OutlinedButton(onClick = onSave) { Text("Guardar WAV") }
            Spacer(Modifier.padding(4.dp))
            OutlinedButton(onClick = onShare) { Text("Partilhar") }
        }
    }
}
