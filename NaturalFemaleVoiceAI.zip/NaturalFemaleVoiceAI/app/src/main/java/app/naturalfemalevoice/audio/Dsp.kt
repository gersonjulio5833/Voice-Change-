package app.naturalfemalevoice.audio

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Utilitários DSP em Kotlin puro (sem dependências Android → testável na JVM). */
object Dsp {

    /** Lê [x] em passos de [step] amostras com interpolação cúbica (Catmull-Rom). */
    fun resampleStep(x: FloatArray, step: Double): FloatArray {
        require(step > 0.0)
        val n = x.size
        if (n < 2) return x.copyOf()
        val outLen = ((n - 1) / step).toInt() + 1
        val out = FloatArray(outLen)
        for (i in 0 until outLen) {
            val t = i * step
            val i1 = t.toInt()
            val f = (t - i1).toFloat()
            val p0 = x[max(i1 - 1, 0)]
            val p1 = x[min(i1, n - 1)]
            val p2 = x[min(i1 + 1, n - 1)]
            val p3 = x[min(i1 + 2, n - 1)]
            out[i] = 0.5f * (2f * p1 + (-p0 + p2) * f +
                (2f * p0 - 5f * p1 + 4f * p2 - p3) * f * f +
                (-p0 + 3f * p1 - 3f * p2 + p3) * f * f * f)
        }
        return out
    }

    /** Converte a taxa de amostragem (com filtro anti-aliasing ao reduzir). */
    fun resample(x: FloatArray, srcRate: Int, dstRate: Int): FloatArray {
        if (srcRate == dstRate || x.isEmpty()) return x.copyOf()
        val src = if (dstRate < srcRate) lowPass(x, 0.45 * dstRate / srcRate) else x
        return resampleStep(src, srcRate.toDouble() / dstRate)
    }

    /** FIR passa-baixo (janela de Hamming). [cutoff] em ciclos/amostra (< 0.5). */
    fun lowPass(x: FloatArray, cutoff: Double, taps: Int = 63): FloatArray {
        val m = taps / 2
        val h = FloatArray(taps)
        var sum = 0.0
        for (k in 0 until taps) {
            val d = (k - m).toDouble()
            val sinc = if (d == 0.0) 2 * cutoff else sin(2 * PI * cutoff * d) / (PI * d)
            val w = 0.54 - 0.46 * cos(2 * PI * k / (taps - 1))
            val v = sinc * w
            h[k] = v.toFloat()
            sum += v
        }
        for (k in 0 until taps) h[k] = (h[k] / sum).toFloat()
        val n = x.size
        val out = FloatArray(n)
        for (i in 0 until n) {
            var acc = 0f
            val k0 = max(0, i + m - (n - 1))
            val k1 = min(taps - 1, i + m)
            for (k in k0..k1) acc += h[k] * x[i + m - k]
            out[i] = acc
        }
        return out
    }

    /** Passa-alto de 1.ª ordem (remove ruído de baixa frequência). */
    fun highPass(x: FloatArray, sampleRate: Int, fc: Double): FloatArray {
        if (x.isEmpty()) return x
        val rc = 1.0 / (2 * PI * fc)
        val dt = 1.0 / sampleRate
        val a = (rc / (rc + dt)).toFloat()
        val out = FloatArray(x.size)
        var prevIn = x[0]
        var prevOut = 0f
        for (i in x.indices) {
            val y = a * (prevOut + x[i] - prevIn)
            out[i] = y
            prevIn = x[i]
            prevOut = y
        }
        return out
    }

    /** Normaliza o pico para [target] (apenas atenua/amplifica de forma linear). */
    fun normalizePeak(x: FloatArray, target: Float = 0.89f): FloatArray {
        var peak = 0f
        for (v in x) peak = max(peak, abs(v))
        if (peak < 1e-6f) return x
        val g = target / peak
        return FloatArray(x.size) { x[it] * g }
    }
}
