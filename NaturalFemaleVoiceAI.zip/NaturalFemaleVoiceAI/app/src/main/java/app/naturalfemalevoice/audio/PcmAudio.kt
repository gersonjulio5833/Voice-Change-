package app.naturalfemalevoice.audio

/** Áudio mono em float [-1, 1]. */
class PcmAudio(val samples: FloatArray, val sampleRate: Int) {
    val durationSec: Double get() = if (sampleRate > 0) samples.size.toDouble() / sampleRate else 0.0
}
