package app.naturalfemalevoice.audio

import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.roundToInt

/** Leitura/escrita WAV (PCM16 mono na escrita; PCM16/Float32 multi-canal na leitura). */
object WavIO {

    fun write(out: OutputStream, audio: PcmAudio) {
        val dataLen = audio.samples.size * 2
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray(Charsets.US_ASCII)).putInt(36 + dataLen)
        header.put("WAVE".toByteArray(Charsets.US_ASCII))
        header.put("fmt ".toByteArray(Charsets.US_ASCII)).putInt(16)
        header.putShort(1).putShort(1).putInt(audio.sampleRate).putInt(audio.sampleRate * 2)
        header.putShort(2).putShort(16)
        header.put("data".toByteArray(Charsets.US_ASCII)).putInt(dataLen)
        out.write(header.array())

        val chunk = 8192
        val buf = ByteBuffer.allocate(chunk * 2).order(ByteOrder.LITTLE_ENDIAN)
        var i = 0
        val s = audio.samples
        while (i < s.size) {
            buf.clear()
            val end = minOf(s.size, i + chunk)
            for (k in i until end) {
                val v = (s[k].coerceIn(-1f, 1f) * 32767f).roundToInt()
                buf.putShort(v.toShort())
            }
            out.write(buf.array(), 0, (end - i) * 2)
            i = end
        }
        out.flush()
    }

    fun toBytes(audio: PcmAudio): ByteArray {
        val bos = ByteArrayOutputStream(44 + audio.samples.size * 2)
        write(bos, audio)
        return bos.toByteArray()
    }

    fun read(bytes: ByteArray): PcmAudio {
        require(bytes.size >= 12) { "Ficheiro WAV demasiado pequeno." }
        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        require(tag(bytes, 0) == "RIFF" && tag(bytes, 8) == "WAVE") { "Não é um ficheiro WAV válido." }

        var pos = 12
        var fmtTag = 1
        var channels = 1
        var sampleRate = 44100
        var bits = 16
        var dataStart = -1
        var dataLen = 0
        while (pos + 8 <= bytes.size) {
            val id = tag(bytes, pos)
            val size = bb.getInt(pos + 4)
            val body = pos + 8
            if (id == "fmt ") {
                fmtTag = bb.getShort(body).toInt() and 0xFFFF
                channels = bb.getShort(body + 2).toInt()
                sampleRate = bb.getInt(body + 4)
                bits = bb.getShort(body + 14).toInt()
            } else if (id == "data") {
                dataStart = body
                val avail = bytes.size - body
                dataLen = if (size < 0 || size > avail) avail else size
                break
            }
            if (size < 0) break
            pos = body + size + (size and 1)
        }
        require(dataStart >= 0) { "WAV sem bloco de dados." }
        require(channels >= 1) { "WAV com número de canais inválido." }

        val isFloat = (fmtTag == 3) || (fmtTag == 0xFFFE && bits == 32)
        val bytesPerSample = bits / 8
        require((bits == 16 && !isFloat) || (bits == 32 && isFloat)) {
            "Formato WAV não suportado ($bits bits)."
        }
        val frames = dataLen / (bytesPerSample * channels)
        val out = FloatArray(frames)
        var p = dataStart
        for (f in 0 until frames) {
            var acc = 0f
            for (c in 0 until channels) {
                acc += if (isFloat) bb.getFloat(p) else bb.getShort(p) / 32768f
                p += bytesPerSample
            }
            out[f] = acc / channels
        }
        return PcmAudio(out, sampleRate)
    }

    private fun tag(b: ByteArray, off: Int) = String(b, off, 4, Charsets.US_ASCII)
}
