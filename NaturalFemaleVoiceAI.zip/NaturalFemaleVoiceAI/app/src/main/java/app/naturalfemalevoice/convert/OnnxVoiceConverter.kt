package app.naturalfemalevoice.convert

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import app.naturalfemalevoice.audio.Dsp
import app.naturalfemalevoice.audio.PcmAudio
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.FloatBuffer

/**
 * Motor de IA LOCAL via ONNX Runtime Mobile. NÃO inclui modelo: o utilizador importa um .onnx.
 *
 * Contrato do modelo (ver docs/MODELOS.md):
 *  - 1.º input: float32 [1, N] (áudio mono, [-1,1], a [modelSampleRate] Hz)
 *  - 1.º output: float32 [1, M] ou [M] (áudio convertido, a [outputSampleRate] Hz)
 * O áudio é processado em blocos para limitar a memória.
 */
class OnnxVoiceConverter(
    private val modelFile: File,
    private val modelSampleRate: Int = 16_000,
    private val outputSampleRate: Int = 16_000,
    private val chunkSeconds: Int = 8,
) : VoiceConverter {

    override suspend fun convert(input: PcmAudio, params: ConversionParams, onProgress: (Float) -> Unit): PcmAudio =
        withContext(Dispatchers.Default) {
            val ctx = currentCoroutineContext()
            require(modelFile.exists()) { "Modelo .onnx não encontrado. Importe um modelo primeiro." }
            val x = Dsp.resample(input.samples, input.sampleRate, modelSampleRate)
            val env = OrtEnvironment.getEnvironment()
            val opts = OrtSession.SessionOptions()
            opts.setIntraOpNumThreads(minOf(4, Runtime.getRuntime().availableProcessors()))
            val session = env.createSession(modelFile.absolutePath, opts)
            try {
                val inputName = session.inputNames.first()
                val chunk = chunkSeconds * modelSampleRate
                val pieces = ArrayList<FloatArray>()
                var pos = 0
                while (pos < x.size) {
                    ctx.ensureActive()
                    val end = minOf(x.size, pos + chunk)
                    val part = x.copyOfRange(pos, end)
                    OnnxTensor.createTensor(env, FloatBuffer.wrap(part), longArrayOf(1, part.size.toLong())).use { t ->
                        session.run(mapOf(inputName to t)).use { res ->
                            pieces.add(extractAudio(res.get(0).value))
                        }
                    }
                    pos = end
                    onProgress(pos.toFloat() / x.size)
                }
                PcmAudio(Dsp.normalizePeak(join(pieces, outputSampleRate / 100)), outputSampleRate)
            } finally {
                session.close()
                opts.close()
            }
        }

    private fun extractAudio(v: Any?): FloatArray = when (v) {
        is FloatArray -> v
        is Array<*> -> {
            val first = v.firstOrNull() ?: error("Saída do modelo vazia.")
            extractAudio(first)
        }
        else -> error("Formato de saída do modelo não suportado (${v?.javaClass?.simpleName}).")
    }

    /** Junta blocos com crossfade linear de [fade] amostras. */
    private fun join(parts: List<FloatArray>, fade: Int): FloatArray {
        if (parts.isEmpty()) return FloatArray(0)
        var acc = parts[0]
        for (i in 1 until parts.size) {
            val b = parts[i]
            val f = minOf(fade, acc.size, b.size)
            val out = FloatArray(acc.size + b.size - f)
            System.arraycopy(acc, 0, out, 0, acc.size - f)
            for (k in 0 until f) {
                val w = (k + 1f) / (f + 1f)
                out[acc.size - f + k] = acc[acc.size - f + k] * (1f - w) + b[k] * w
            }
            System.arraycopy(b, f, out, acc.size, b.size - f)
            acc = out
        }
        return acc
    }
}
