package app.naturalfemalevoice.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** Reprodução em streaming via AudioTrack (funciona em qualquer API ≥ 23). */
class PcmPlayer {
    private var job: Job? = null
    @Volatile private var track: AudioTrack? = null

    fun play(scope: CoroutineScope, audio: PcmAudio, onDone: (Throwable?) -> Unit) {
        stop()
        job = scope.launch(Dispatchers.IO) {
            var failure: Throwable? = null
            try {
                val minBuf = AudioTrack.getMinBufferSize(
                    audio.sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                )
                check(minBuf > 0) { "Taxa de amostragem não suportada pelo dispositivo (${audio.sampleRate} Hz)." }
                val t = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build(),
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(audio.sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build(),
                    )
                    .setBufferSizeInBytes(minBuf * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                track = t
                t.play()
                val chunk = 4096
                val tmp = ShortArray(chunk)
                var i = 0
                val s = audio.samples
                while (i < s.size && isActive) {
                    val end = minOf(s.size, i + chunk)
                    for (k in i until end) tmp[k - i] = (s[k].coerceIn(-1f, 1f) * 32767f).roundToInt().toShort()
                    val w = t.write(tmp, 0, end - i)
                    if (w < 0) error("Erro de reprodução ($w).")
                    i = end
                }
                if (isActive) t.stop()
            } catch (e: Throwable) {
                failure = e
            } finally {
                try { track?.release() } catch (_: Throwable) {}
                track = null
            }
            onDone(failure)
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        try { track?.pause(); track?.flush() } catch (_: Throwable) {}
    }
}
