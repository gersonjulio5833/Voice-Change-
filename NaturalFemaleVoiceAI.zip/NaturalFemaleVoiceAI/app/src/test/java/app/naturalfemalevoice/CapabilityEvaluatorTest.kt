package app.naturalfemalevoice

import app.naturalfemalevoice.device.CapabilityEvaluator
import app.naturalfemalevoice.device.Tier
import org.junit.Assert.assertFalse
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CapabilityEvaluatorTest {
    private fun eval(abis: List<String>, ram: Long, cores: Int = 8, storage: Long = 2000, lowRam: Boolean = false) =
        CapabilityEvaluator.evaluate(34, abis, ram, cores, storage, lowRam, true, true)

    @Test fun highEndSupportsLocalAi() {
        val r = eval(listOf("arm64-v8a"), 7500)
        assertEquals(Tier.HIGH, r.tier); assertTrue(r.localAiSupported)
    }
    @Test fun lowRamDisablesLocalAiButNotInstall() {
        val r = eval(listOf("arm64-v8a"), 1800, lowRam = true)
        assertEquals(Tier.LOW, r.tier); assertFalse(r.localAiSupported); assertTrue(r.notes.isNotEmpty())
    }
    @Test fun thirtyTwoBitDisablesLocalAi() {
        assertFalse(eval(listOf("armeabi-v7a"), 4000).localAiSupported)
    }
    @Test fun lowStorageDisablesLocalAi() {
        assertFalse(eval(listOf("arm64-v8a"), 4000, storage = 100).localAiSupported)
    }
}
