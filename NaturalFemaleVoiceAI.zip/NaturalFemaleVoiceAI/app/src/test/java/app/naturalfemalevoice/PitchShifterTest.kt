package app.naturalfemalevoice

import app.naturalfemalevoice.audio.Dsp
import app.naturalfemalevoice.audio.PitchShifter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.sin

class PitchShifterTest {
    private val sr = 16000
    private fun sine(hz: Double) = FloatArray(sr * 2) { sin(2 * PI * hz * it / sr).toFloat() }
    private fun freq(x: FloatArray): Double {
        var zc = 0
        for (i in 1 until x.size) if (x[i - 1] < 0f && x[i] >= 0f) zc++
        return zc / (x.size.toDouble() / sr)
    }

    @Test
    fun shiftsFrequencyAndKeepsDuration() {
        for (ratio in listOf(1.25, 1.5, 0.8)) {
            val y = PitchShifter.pitchShift(sine(200.0), sr, ratio)
            assertEquals("duração ratio=$ratio", 1.0, y.size / (sr * 2.0), 0.03)
            assertEquals("freq ratio=$ratio", 200.0 * ratio, freq(y), 200.0 * ratio * 0.05)
        }
    }

    @Test
    fun resampleChangesLengthProportionally() {
        val y = Dsp.resample(sine(200.0), 16000, 8000)
        assertEquals(sr.toDouble(), y.size.toDouble(), 4.0)
    }

    @Test
    fun normalizeReachesTarget() {
        val y = Dsp.normalizePeak(floatArrayOf(0.1f, -0.2f, 0.05f), 0.8f)
        assertTrue(y.maxOf { kotlin.math.abs(it) } in 0.79f..0.81f)
    }
}
