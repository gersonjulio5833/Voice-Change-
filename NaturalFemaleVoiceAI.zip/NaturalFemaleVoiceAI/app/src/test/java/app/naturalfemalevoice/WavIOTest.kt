package app.naturalfemalevoice

import app.naturalfemalevoice.audio.PcmAudio
import app.naturalfemalevoice.audio.WavIO
import org.junit.Assert.assertEquals
import org.junit.Test
import kotlin.math.PI
import kotlin.math.sin

class WavIOTest {
    @Test
    fun roundTripKeepsSamplesAndRate() {
        val src = FloatArray(4000) { 0.5f * sin(2 * PI * 440 * it / 16000).toFloat() }
        val back = WavIO.read(WavIO.toBytes(PcmAudio(src, 16000)))
        assertEquals(16000, back.sampleRate)
        assertEquals(src.size, back.samples.size)
        for (i in src.indices) assertEquals(src[i], back.samples[i], 1f / 16384f)
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsGarbage() {
        WavIO.read(ByteArray(64))
    }
}
