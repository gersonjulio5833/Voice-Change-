# Compatibilidade

## Decisões
- **minSdk 26 (Android 8.0)**, compileSdk/targetSdk 35. ONNX Runtime Mobile 1.19, Compose e AudioTrack/AudioRecord/MediaCodec funcionam desde a API 26.
- Nenhuma API de fabricante. Só APIs padrão do Android (AudioRecord, AudioTrack, MediaCodec, SAF, FileProvider).
- Nenhum `uses-feature` obrigatório (microfone e touchscreen são `required="false"`): a instalação não é bloqueada por hardware.
- ABIs: `arm64-v8a`, `armeabi-v7a`, `x86_64`, `x86`. Gera-se um **APK universal** + um APK por ABI.
- Ecrã: layout de 1 coluna em telemóvel e 2 colunas ≥ 720 dp (tablets/dobráveis); tema claro/escuro; cores dinâmicas em Android 12+; edge-to-edge com insets.
- Sem permissões de armazenamento: importação/exportação via Storage Access Framework; partilha via FileProvider.

## Avaliação do dispositivo (`CapabilityEvaluator`)
| Condição | Efeito |
|---|---|
| CPU sem ABI de 64 bits | IA local desativada |
| RAM total < 2800 MB ou `isLowRamDevice` | Nível LOW, IA local desativada |
| Armazenamento livre < 300 MB | IA local desativada |
| Sem microfone | Gravar não funciona; importar sim |
| Qualquer dispositivo | Motor básico + nuvem sempre disponíveis |
O bloqueio da IA local tem sempre razão técnica explícita mostrada ao utilizador, com alternativa.

## Limites conhecidos
- Áudio máx. 5 min por ficheiro (memória). Motor básico processa a ≤ 24 kHz.
- Alguns ROMs têm Keystore defeituoso: o token da nuvem fica então só em memória (sem persistência).
- Alguns fabricantes (Xiaomi/Huawei/OPPO/vivo) limitam apps em segundo plano: a conversão deve ser feita com a app em primeiro plano.
- Dispositivos sem codec MP3/AAC raros podem falhar a importar certos formatos; WAV funciona sempre.

## Matriz de testes (a preencher — NENHUM teste em dispositivo foi feito)
| Marca/modelo | Android | ABI | Instala | Grava | Converte (DSP) | ONNX | Nuvem | Notas |
|---|---|---|---|---|---|---|---|---|
| | | | | | | | | |
Sugestão: testar pelo menos Android 8, 10, 12, 14 e 15, um aparelho de 32 bits, um de ≤ 3 GB RAM e um tablet.
