# Motores de conversão: requisitos e limitações

## 1. Básico (DSP) — incluído
- Pipeline: reamostragem ≤ 24 kHz → passa-alto 60 Hz → WSOLA (time-stretch) → reamostragem cúbica → normalização.
- Eleva tom **e** formantes na mesma razão (1.0–1.6). Resultado: voz mais aguda e "menor", sem controlo independente do tom, sem clonagem de timbre, sotaque ou entoação.
- Custo: baixo (~segundos para 1 min em telemóveis modestos). Offline.
- **Não cumpre sozinho** "voz feminina natural com o timbre/sotaque dos áudios de referência": serve como alternativa universal e fallback.

## 2. IA local (ONNX) — requer modelo do utilizador
Sem modelo, o motor não faz nada. O projeto **não inclui nenhum modelo**.
**Contrato esperado:**
- Input 1: `float32 [1, N]`, mono, [-1, 1], 16 kHz.
- Output 1: `float32 [1, M]` ou `[M]`, 16 kHz.
- Blocos de 8 s com crossfade de 10 ms.
- Não alimenta a voz de referência (só um input). Modelos que exigem embedding/feature extractor separado (ex.: RVC clássico com HuBERT + F0, kNN-VC com WavLM) **precisam de um grafo ONNX que os una**, ou de adaptação do código em `OnnxVoiceConverter`.
**Requisitos:** CPU 64 bits, ≥ ~2.8 GB RAM, ≥ 300 MB livres + tamanho do modelo. Modelos de 50–200 MB são realistas; maiores arriscam OOM e lentidão sem GPU/NNAPI (a app usa só CPU, até 4 threads).
**Limitação sobre as referências:** dois dos três áudios têm ~2 s — insuficiente para treinar (RVC/similares precisam de minutos de fala limpa) e marginal para *zero-shot*. O de ~2 min é utilizável como referência zero-shot. Para treino de um modelo próprio, use gravações limpas e com direitos de uso.

## 3. IA na nuvem — endpoint do utilizador
`POST` multipart/form-data para URL HTTPS:
- `audio`: WAV PCM16 mono 16 kHz
- `reference`: WAV mono ≤16 kHz (opcional, se escolheu referência)
- `pitch_ratio`: texto (informativo)
- Cabeçalho `Authorization: Bearer <token>` se token definido
Resposta: 200 com corpo WAV (PCM16 ou float32, qualquer nº de canais/taxa).
Não está incluído servidor. Qualquer serviço/self-hosted (ex.: um wrapper FastAPI sobre OpenVoice/kNN-VC/RVC) que respeite o contrato funciona. **Privacidade:** o áudio sai do telemóvel; use só endpoints em que confia. Timeout de leitura: 3 min.

## Tempo real
Não implementado. Requereria streaming com latência < ~100 ms (Oboe/AAudio, modelo causal), só realista em dispositivos topo de gama com FEATURE_AUDIO_LOW_LATENCY e um modelo específico. Mesmo assim, o Android não permite injetar o resultado no microfone de outras apps.
