# Natural Female Voice AI

Aplicação Android (Kotlin + Jetpack Compose) para gravar/importar áudio, converter a voz, pré-visualizar, guardar (WAV) e partilhar.
Compatível com qualquer marca Android (minSdk 26 / Android 8.0), sem funcionalidades exclusivas de fabricante.

## ⚠️ Estado real do projeto (leia primeiro)

| Item | Estado |
|---|---|
| Código-fonte, workflow, testes, docs | Escritos |
| Algoritmo de DSP (WSOLA + reamostragem) | Validado num protótipo Python equivalente (frequência e duração corretas) |
| Compilação Gradle / APK | **NÃO validada** — o ambiente onde o projeto foi escrito não tinha Android SDK, Gradle nem rede |
| Testes unitários JUnit | **Escritos, mas NÃO executados** |
| Teste em dispositivos reais | **Nenhum** |

O primeiro passo é correr o workflow do GitHub Actions: se falhar, o log indica o erro exato (é normal surgir 1–2 ajustes na primeira compilação).

## Motores de conversão

1. **Básico (DSP)** – offline, qualquer telemóvel. Sobe tom e formantes em conjunto (WSOLA + reamostragem cúbica). **Não é clonagem de voz por IA**; dá uma voz mais aguda, não a voz dos áudios de referência.
2. **IA local (ONNX Runtime)** – requer que importe um modelo `.onnx` compatível (não incluído). Só ativo em CPU 64 bits com ≥ ~2.8 GB de RAM reportada.
3. **IA na nuvem** – envia o áudio para um endpoint HTTPS **seu** (URL/token introduzidos na app; nada no código).

Detalhes, contratos e limitações: [docs/MODELOS.md](docs/MODELOS.md). Compatibilidade: [docs/COMPATIBILIDADE.md](docs/COMPATIBILIDADE.md).

## Vozes de referência
`app/src/main/assets/reference_voices/` contém os 3 áudios enviados (dois de ~2 s e um de ~2 min). São oferecidos como voz-alvo aos motores de IA (local/nuvem). O motor básico não os usa.
**Licenças:** confirme que pode redistribuir estes áudios (ElevenLabs, Pixabay, Freesound têm termos próprios). Se o repositório for público, verifique-os ou remova-os.

## Compilar na nuvem (sem computador local)
1. Crie um repositório no GitHub e envie esta pasta (pode fazê-lo pelo browser do telemóvel: *Add file → Upload files*).
2. Separador **Actions → Build APK → Run workflow** (também corre em cada push).
3. No fim, em *Artifacts*, descarregue `NaturalFemaleVoiceAI-debug-apk` (ZIP com `app-universal-debug.apk` e APKs por ABI).
4. **Mais fácil no telemóvel:** crie uma tag `v1.0.0` (*Releases → Draft a new release*) — o APK fica anexado à Release, descarregável sem login.

## Instalar no telemóvel
1. Descarregue `app-universal-debug.apk`.
2. Abra-o; se pedido, permita "Instalar apps desconhecidas" para o browser/gestor de ficheiros.
3. Instale e abra. Aceite a permissão de microfone ao gravar.
É um APK de **depuração** (assinado com a chave debug automática do Gradle), adequado a uso pessoal/testes.

## Compilar localmente (opcional)
JDK 17 + Android SDK 35 + Gradle 8.9: `gradle testDebugUnitTest assembleDebug`
(o wrapper não está incluído; gere-o com `gradle wrapper --gradle-version 8.9`).

## O que a app NÃO faz
- **Não substitui o microfone de outras apps** (WhatsApp, Messenger, TikTok, Snapchat…). O Android não permite isso a apps normais; só seria possível com root/ROM modificada. Alternativa: converter → guardar/partilhar o áudio e enviá-lo como mensagem de voz.
- **Sem conversão em tempo real.** O relatório do dispositivo indica se seria teoricamente viável, mas não está implementado.
- Exportação apenas em WAV (PCM16 mono).

## Estrutura
`audio/` captura, descodificação, DSP, WAV, reprodução · `convert/` motores · `device/` avaliação de capacidades · `data/` definições (token em EncryptedSharedPreferences) e referências · `ui/` Compose.
